create function st_angle(line1 geometry, line2 geometry) returns double precision
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT public.ST_Angle(public.St_StartPoint($1), public.ST_EndPoint($1), public.ST_StartPoint($2), public.ST_EndPoint($2))$$;

alter function st_angle(geometry, geometry) owner to postgres;

