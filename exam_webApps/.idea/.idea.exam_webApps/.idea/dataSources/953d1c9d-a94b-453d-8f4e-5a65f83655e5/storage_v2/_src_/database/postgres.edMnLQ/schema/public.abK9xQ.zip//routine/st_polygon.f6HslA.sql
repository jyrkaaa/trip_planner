create function st_polygon(geometry, integer) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$
	SELECT public.ST_SetSRID(public.ST_MakePolygon($1), $2)
	$$;

alter function st_polygon(geometry, integer) owner to postgres;

